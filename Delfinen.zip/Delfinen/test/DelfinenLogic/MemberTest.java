/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DelfinenLogic;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Rasmus2
 */
public class MemberTest {
    
    public  MemberTest() {
        
    }
    
    @Test
    public void testCreateNewMember() {
        Member m = new Member("0593205944", "Lars");
        assertNotNull(m);
        assertEquals("Lars", m.getName());
        assertEquals("0593205944", m.getSsn());
        assertEquals(10, m.getSsn().length());
    }
}

