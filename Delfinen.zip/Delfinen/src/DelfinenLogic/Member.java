/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DelfinenLogic;

/**
 *
 * @author Rasmus2
 */
public class Member {
    private String ssn;
    private String name;

    public Member(String ssn, String name) {
        this.ssn = ssn;
        this.name = name;
    }

    public String getSsn() {
        return ssn;
    }

    public String getName() {
        return name;
    }
    
}
